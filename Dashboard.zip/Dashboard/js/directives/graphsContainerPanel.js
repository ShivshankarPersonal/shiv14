(function () {
    'use strict';
    angular.module("graphsContainerPanel", [])
        .directive("graphsContainerPanel", function ($timeout, dashboardFactory) {
            return {
                restrict: 'E',
                templateUrl: 'templates/graphsContainerPanel.html',
                link: function ($scope) {
                    $scope.showOverlay = false;
                    $scope.canvasElement = null;
                    $scope.canvasContext = null;
                    $scope.chartInstance = null;
                    $scope.scales = ['scaleRight', 'scaleLeft'];
                    var globalChartSettings = {};
                    $scope.border = 1;
                    $scope.pointStyle = "circle";
                    $scope.onBefore5min = function () {
                        $scope.data = dashboardFactory.graphsData[0]['5min'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore15min = function () {
                        $scope.data = dashboardFactory.graphsData[1]['15min'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore30min = function () {
                        $scope.data = dashboardFactory.graphsData[2]['30min'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore1h = function () {
                        $scope.data = dashboardFactory.graphsData[3]['1h'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore4h = function () {
                        $scope.data = dashboardFactory.graphsData[4]['4h'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore1D = function () {
                        $scope.data = dashboardFactory.graphsData[5]['1D'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore1W = function () {
                        $scope.data = dashboardFactory.graphsData[6]['1W'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onBefore1M = function () {
                        $scope.data = dashboardFactory.graphsData[7]['1M'];
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onSettingsBtnClick = function () {
                        $scope.showOverlay = !$scope.showOverlay;
                    };
                    $scope.onDefaults = function () {
                        $scope.showOverlay = false;
                        globalChartSettings.borderWidth = 2;
                        $scope.borderWidth = 2;
                        globalChartSettings.backgroundColor = "rgba(75,192,192,0.4)";
                        globalChartSettings.borderColor = "rgba(75,192,192,1)";
                        $scope.scale = 'scaleLeft';
                        globalChartSettings.scalePosition = 'left';
                        $scope.yAxisDataType = "autoscale";
                        globalChartSettings.yAxisDataType = "autoscale";
                        $scope.showToolTip = true;
                        globalChartSettings.showToolTip = true;
                        $scope.xAxisLabelIndicator = true;
                        $scope.yAxisLabelIndicator = true;
                        globalChartSettings.xAxisLabelIndicator = true;
                        globalChartSettings.yAxisLabelIndicator = true;
                        $scope.topMargin = 15;
                        $scope.bottomMargin = 15;
                        globalChartSettings.topMargin = 15;
                        globalChartSettings.bottomMargin = 15;
                        $scope.vertGridLinesWidth = 1;
                        globalChartSettings.vertGridLinesWidth = 1;
                        $scope.vertGridLinesColor = "rgba(236, 236, 236,.9)";
                        globalChartSettings.vertGridLinesColor = 'rgba(220, 217, 217,.9)';
                        $scope.horizontalGridLinesColor = 'rgba(236, 236, 236,.9)';
                        globalChartSettings.horizontalGridLinesColor = 'rgba(220, 217, 217,.9)';
                        $scope.horizontalGridLinesWidth = 1;
                        globalChartSettings.horizontalGridLinesWidth = 1;
                        $scope.scaleLabelTextColor = 'gray';
                        globalChartSettings.scaleLabelTextColor = 'gray';
                        $scope.scaleLabelTextSize = 16;
                        globalChartSettings.scaleLabelTextSize = 16;
                        $scope.zeroLineColor = 'gray';
                        globalChartSettings.zeroLineColor = 'gray';
                        $scope.annotationFontSize = 14;
                        globalChartSettings.annotationFontSize = 14;
                        $scope.showAnnotatedText = true;
                        globalChartSettings.showAnnotatedText = true;
                        $scope.showAnnotatedTextBox = true;
                        $scope.backgroundColorCanvas = 'rgb(247, 247, 247)';
                        globalChartSettings.backgroundColorCanvas = 'rgb(247, 247, 247)';
                        generateGraph();
                    };
                    $scope.onOK = function () {
                        $scope.showOverlay = false;
                        globalChartSettings.borderWidth = $scope.borderWidth;
                        globalChartSettings.borderColor = $scope.lineColor;
                        globalChartSettings.backgroundColor = $scope.backgroundColor;
                        globalChartSettings.scalePosition = $scope.scale.substring(5, $scope.scale.length).toLowerCase();
                        globalChartSettings.yAxisDataType = $scope.yAxisDataType;
                        globalChartSettings.showToolTip = $scope.showToolTip;
                        globalChartSettings.xAxisLabelIndicator = $scope.xAxisLabelIndicator;
                        globalChartSettings.yAxisLabelIndicator = $scope.yAxisLabelIndicator;
                        globalChartSettings.topMargin = $scope.topMargin;
                        globalChartSettings.bottomMargin = $scope.bottomMargin;
                        globalChartSettings.vertGridLinesColor = $scope.vertGridLinesColor;
                        globalChartSettings.vertGridLinesWidth = $scope.vertGridLinesWidth;
                        globalChartSettings.horizontalGridLinesColor = $scope.horizontalGridLinesColor;
                        globalChartSettings.horizontalGridLinesWidth = $scope.horizontalGridLinesWidth;
                        globalChartSettings.scaleLabelTextColor = $scope.scaleLabelTextColor;
                        globalChartSettings.scaleLabelTextSize = $scope.scaleLabelTextSize;
                        globalChartSettings.zeroLineColor = $scope.zeroLineColor;
                        globalChartSettings.showAnnotatedText = $scope.showAnnotatedText;
                        $scope.showAnnotatedTextBox = globalChartSettings.showAnnotatedText;
                        globalChartSettings.backgroundColorCanvas = $scope.backgroundColorCanvas;
                        if ($scope.fillType === 'start' && $scope.type === 'line') {
                            $scope.type = 'area';
                        }
                        generateGraph();
                    };
                    $scope.onCancel = function () {
                        $scope.showOverlay = false;
                    };
                    $scope.onSettingsCloseIconClick = function () {
                        $scope.showOverlay = false;
                    };
                    function generateGraph() {
                        if ($scope.canvasContext) {
                            $scope.canvasContext.clearRect(0, 0, $scope.canvasElement.width, $scope.canvasElement.height);
                        }
                        if ($scope.chartInstance) {
                            $scope.chartInstance.destroy();
                        }
                        $scope.fillType = 'start';
                        if ($scope.type === 'line') {
                            $scope.fillType = false;
                        } else if ($scope.type === 'area') {
                            $scope.fillType = 'start';
                            $scope.type = 'line'
                        }
                        var options = {
                            type: $scope.type,
                            data: {
                                labels: ["Persistent", "TCS", "Infosys", "Wipro", "Cognizant", "Accenture", "IBM", "TechM"],
                                datasets: [
                                    {
                                        label: 'Market Share Value',
                                        data: $scope.data,
                                        borderWidth: globalChartSettings.borderWidth,
                                        fill: $scope.fillType,
                                        lineTension: .0001,
                                        backgroundColor: globalChartSettings.backgroundColor,
                                        borderColor: globalChartSettings.borderColor,
                                        borderCapStyle: 'square',
                                        borderDash: [],
                                        borderDashOffset: 0.0,
                                        borderJoinStyle: 'miter',
                                        pointBorderColor: "rgba(75,192,192,1)",
                                        pointBackgroundColor: "rgba(75,192,192,1)",
                                        pointBorderWidth: 1,
                                        pointHoverRadius: 12,
                                        pointHoverBackgroundColor: "rgba(75,192,192,1)",
                                        pointHoverBorderColor: "rgba(75,192,192,1)",
                                        pointHoverBorderWidth: 2,
                                        pointRadius: 7,
                                        pointHitRadius: 10,
                                        showLine: true
                                    }
                                ]
                            },
                            options: {
                                scales: {
                                    yAxes: [{
                                        ticks: {
                                            reverse: false,
                                            fontColor: globalChartSettings.scaleLabelTextColor,
                                            fontSize: globalChartSettings.scaleLabelTextSize,
                                            callback: function (value) {
                                                var dataType = '';
                                                if (globalChartSettings.yAxisDataType === "percentage") {
                                                    dataType = "%"
                                                } else {
                                                    dataType = ""
                                                }
                                                return value + dataType
                                            }
                                        },
                                        position: globalChartSettings.scalePosition,
                                        gridLines: {
                                            color: globalChartSettings.vertGridLinesColor,
                                            lineWidth: globalChartSettings.vertGridLinesWidth,
                                            zeroLineColor: globalChartSettings.zeroLineColor
                                        }
                                    }],
                                    xAxes: [{
                                        gridLines: {
                                            color: globalChartSettings.horizontalGridLinesColor,
                                            lineWidth: globalChartSettings.horizontalGridLinesWidth,
                                            zeroLineColor: globalChartSettings.zeroLineColor
                                        },
                                        ticks: {
                                            fontColor: globalChartSettings.scaleLabelTextColor,
                                            fontSize: globalChartSettings.scaleLabelTextSize
                                        }
                                    }]
                                },
                                elements: {
                                    point: {
                                        pointStyle: $scope.pointStyle
                                    }
                                },
                                tooltips: {
                                    enabled: globalChartSettings.showToolTip
                                },
                                title: {
                                    display: globalChartSettings.yAxisLabelIndicator,
                                    text: 'Share Values of Indian IT Co.',
                                    position: 'left',
                                    fontSize: 18,
                                    fontColor: globalChartSettings.scaleLabelTextColor
                                },
                                layout: {
                                    padding: {
                                        top: globalChartSettings.topMargin,
                                        bottom: globalChartSettings.bottomMargin
                                    }
                                },
                                animation: {
                                    duration: 4000,
                                    easing: 'easeOutBounce'
                                }
                            }
                        };
                        $scope.canvasElement = document.getElementById('canvasContainer');
                        $scope.canvasContext = $scope.canvasElement.getContext('2d');
                        $scope.chartInstance = new Chart($scope.canvasContext, options);
                        $timeout(function(){
                            $scope.canvasElement.style.backgroundColor = globalChartSettings.backgroundColorCanvas;
                        },100);

                    }

                    $timeout(function () {
                        $scope.data = dashboardFactory.graphsData[0]['5min'];
                        $scope.type = 'line';
                        $scope.onDefaults();
                        generateGraph();
                    }, 200);
                    $("#lineColor, #backgroundColor,#backgroundColorOpt, #backgroundColorCanvas, #vertGridLinesColor, #horizontalGridLinesColor, #scaleLabelTextColor, #zeroLineColor, #annotationFontColor, #annotationTextColor, #annotationBorderColor").spectrum({
                        showPaletteOnly: true,
                        togglePaletteOnly: true,
                        togglePaletteMoreText: 'more',
                        togglePaletteLessText: 'less',
                        color: 'rgb(75,192,192)',
                        palette: [
                            ["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
                            ["#f00", "#f90", "#ff0", "#0f0", "#0ff", "#00f", "#90f", "#f0f"],
                            ["#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#cfe2f3", "#d9d2e9", "#ead1dc"],
                            ["#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#9fc5e8", "#b4a7d6", "#d5a6bd"],
                            ["#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6fa8dc", "#8e7cc3", "#c27ba0"],
                            ["#c00", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3d85c6", "#674ea7", "#a64d79"],
                            ["#900", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#0b5394", "#351c75", "#741b47"],
                            ["#600", "#783f04", "#7f6000", "#274e13", "#0c343d", "#073763", "#20124d", "#4c1130"]
                        ]
                    });
                    $scope.onFullScreenChart = function ($event) {
                        var graphContainer = angular.element(document.getElementsByClassName('graphContainer'));
                        var maximizeMinimizeIconElement = angular.element($event.target);
                        if (maximizeMinimizeIconElement.hasClass('glyphicon-fullscreen')) {
                            graphContainer.addClass('maximizeChart');
                            maximizeMinimizeIconElement.removeClass('glyphicon-fullscreen').addClass('glyphicon-resize-small');
                        } else {
                            maximizeMinimizeIconElement.removeClass('glyphicon-resize-small').addClass('glyphicon-fullscreen');
                            graphContainer.removeClass('maximizeChart');
                        }
                    };
                    $scope.onExportToImageClick = function ($event) {
                        if (window.navigator.msSaveOrOpenBlob) {
                            var blobObject = new Blob([document.getElementById('canvasContainer').toDataURL()], {type: "image/png"});
                            window.navigator.msSaveBlob(blobObject, 'graph.png')
                        } else {
                            var pngElement = document.getElementById('exportToPNG');
                            pngElement.href = document.getElementById('canvasContainer').toDataURL();
                            pngElement.download = "graph";
                        }
                    };
                    $scope.onZoomInClick = function () {

                    };
                    $scope.onCrossPointer = function () {
                        $scope.pointStyle = "cross";
                        generateGraph();
                    };
                    $scope.onDotPointer = function () {
                        $scope.pointStyle = "circle";
                        generateGraph();
                    };
                    $scope.onArrowPointer = function () {
                        $scope.pointStyle = "triangle";
                        generateGraph();
                    };
                    $scope.onDisplayBarChart = function () {
                        $scope.type = "bar";
                        generateGraph();
                    };
                    $scope.onDisplayLineChart = function () {
                        $scope.type = "line";
                        generateGraph();
                    };
                    $scope.onDisplayAreaChart = function () {
                        $scope.type = "area";
                        generateGraph();
                    };

                    $timeout(function () {
                        var annotationText = document.getElementById("annotationContainer");
                        annotationText.addEventListener("click", function () {
                            $scope.annotationTextProcessingContainer = true;
                            if (!$scope.$$phase) {
                                $scope.$apply();
                            }
                        }, false)
                    }, 200);

                    $scope.annotationFontFamilies = ["sans-serif", "serif", "monospace", "fantasy", "cursive"];
                    $scope.annotationTextProcessingContainer = false;
                    $scope.onCloseAnnotationWindow = function () {
                        $scope.annotationTextProcessingContainer = false;
                    };
                    $scope.onAnnotationDefaults = function () {
                        $scope.annotationTextProcessingContainer = false;
                        $scope.userAnnotation = "My Annotations";
                        $scope.annotationTextColor = 'gray';
                        $scope.annotationFontFamily = "sans-serif";
                        $scope.annotationFontSize = 16;
                        $scope.annotationTextWrap = false;
                        $scope.annotationBorder = true;
                        globalChartSettings.annotationBorder = true;
                        $scope.annotationBorderColor = "rgb(75, 192, 192)";
                        globalChartSettings.annotationBorderColor = "rgb(75, 192, 192)";
                    };
                    $scope.onAnnotationOK = function () {
                        $scope.annotationTextProcessingContainer = false;
                        globalChartSettings.annotationBorderColor = $scope.annotationBorderColor;
                        var wordWrap = 'normal';
                        if($scope.annotationTextWrap){
                            wordWrap = 'break-word';
                        }
                        if($scope.annotationBorder){
                            globalChartSettings.annotationBorder = 1;
                        }else {
                            globalChartSettings.annotationBorder = 0;
                        }
                        angular.element(document.getElementById("annotationText")).attr("style", 'color:' + $scope.annotationTextColor + ';' + 'font-family:' + $scope.annotationFontFamily + ';' + 'font-size:'+$scope.annotationFontSize + 'px;' + 'word-wrap:' + wordWrap);
                        angular.element(document.getElementById("annotationContainer")).attr("style",'border-color-width:' + globalChartSettings.annotationBorder + 'px;' + 'border-color:' + globalChartSettings.annotationBorderColor + ';');
                        $scope.userAnnotation = $scope.annotationComment;

                    };
                    $scope.onAnnotationCancel = function () {
                        $scope.annotationTextProcessingContainer = false;
                    };
                    $scope.onAnnotationDefaults();

                }
            }
        })
})();
