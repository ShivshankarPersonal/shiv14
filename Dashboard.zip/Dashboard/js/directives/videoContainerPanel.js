(function () {
    'use strict';
    angular.module("videoContainerPanel", [])
        .directive("videoContainerPanel", function ($timeout) {
            return {
                restrict: 'E',
                templateUrl: "templates/videoContainerPanel.html",
                scope: {
                    title: "@",
                    video: "@"
                },
                link: function ($scope, element, attr) {
                    $scope.videoURLMP4 = "resources/videos/" + $scope.video + ".mp4?" + Date.now();
                    $scope.videoURLOGG = "resources/videos/" + $scope.video + ".ogg?" + Date.now();
                    $scope.videoURLWEBM = "resources/videos/" + $scope.video + ".ogg?" + Date.now();

                    $scope.minimizePanel = function () {
                        var minizeIconElement = angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-minus')));
                        var originalParent = angular.element(document.getElementsByClassName('video' + attr.number));
                        if (minizeIconElement.length) {
                            angular.element(document.getElementsByClassName('minimizedPanelsHolder')).append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-minus'))).removeClass('glyphicon-minus').addClass('glyphicon-modal-window');
                        } else {
                            originalParent.append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-modal-window'))).removeClass('glyphicon-modal-window').addClass('glyphicon-minus');
                        }
                    };
                    $scope.maximizePanel = function () {
                        var originalParent = angular.element(document.getElementsByClassName('video' + attr.number));
                        if (angular.element(element).parent().hasClass('maximizePanel')) {
                            angular.element(element).parent().removeClass('maximizePanel');
                        } else {
                            originalParent.append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-modal-window'))).removeClass('glyphicon-modal-window').addClass('glyphicon-minus');
                            angular.element(element).parent().addClass('maximizePanel');
                        }
                    };

                    //Stop Video
                    $scope.stopVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        // var progressElementsClassName = angular.element(element).find('.'+'progress'+videoElementsId).attr('class');
                        var progressElement = angular.element(element).find('.' + 'progress' + videoElementsId);

                        videoElement.pause();
                        videoElement.currentTime = 0;
                        progressElement.value = 0;
                    };
                    //Play Video
                    $scope.playVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        videoElement.play()
                    };

                    //Pause Video
                    $scope.pauseVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        videoElement.pause()
                    };
                    //Mute Video
                    $scope.muteVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        videoElement.muted = !videoElement.muted;
                        var muteElement = angular.element(element).find('.mute' + videoElementsId);
                        var isMuteIconPresent = angular.element(muteElement).hasClass('glyphicon-volume-off');
                        if (isMuteIconPresent) {
                            angular.element(muteElement).removeClass('glyphicon-volume-off');
                            angular.element(muteElement).addClass('glyphicon-bullhorn');
                        } else {
                            angular.element(muteElement).addClass('glyphicon-volume-off');
                            angular.element(muteElement).removeClass('glyphicon-bullhorn');
                        }
                    };
                    //Decrease Volume
                    $scope.volumeDown = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        tuneVolumeOfVideoPlayer("-", videoElement)
                    };
                    //Increase Volume
                    $scope.volumeUp = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        tuneVolumeOfVideoPlayer("+", videoElement)
                    };

                    // Progress bar
                    $timeout(function () {
                        // As the video is playing, update the progress bar
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var video = document.getElementById(videoElementsId);
                        if (video.readyState > 0) {
                            $scope["videoDuration" + $scope.video] = video.duration;
                        }
                        video.addEventListener('durationchange', onDurationChange, false);
                        $scope.timingMap = {};
                        function onDurationChangeDuringVideoPlay(me) {
                            if (!isNaN(parseInt(me.duration))) {
                                $scope.timingMap[me.id] = parseInt(me.currentTime).toString() + "/" + parseInt(me.duration).toString();
                                $scope.currentTiming = parseInt(me.currentTime).toString();
                                $scope.durationTiming = parseInt(me.duration).toString();
                                if (!$scope.$$phase) {
                                    $scope.$apply();
                                }
                            }
                        }

                        function onDurationChange() {
                            $scope.timingMap[this.id] = parseInt(this.currentTime).toString() + "/" + parseInt(this.duration).toString();
                            if (!$scope.$$phase) {
                                $scope.$apply();
                            }
                        }

                        $timeout(function () {
                            $scope.getDurationDetails = function (videoNumber) {
                                return $scope.timingMap[videoNumber];
                            };
                        }, 200);

                        var supportsProgress = (document.createElement('progress').max !== undefined);
                        if (!supportsProgress) progress.setAttribute('data-state', 'fake');

                        video.addEventListener('ended', onVideoEnd, false);
                        function onVideoEnd() {
                            var isPlaying = video.currentTime > 0 && !video.paused && !video.ended
                                && video.readyState > 2;
                            if (!isPlaying) {
                                video.play();
                            }
                        }

                        video.addEventListener('timeupdate', function () {
                            if (video.readyState > 2) {
                                var videoElementsId = angular.element(videoElementInProcess).attr('id');
                                var progressElement = angular.element(element).find('.' + 'progress' + videoElementsId);
                                var duration = video.duration;
                                if (!angular.element(progressElement).attr('max')) {
                                    angular.element(progressElement).attr('max', duration)
                                }
                                angular.element(progressElement).attr('value', video.currentTime)
                                var width = Math.floor(($scope.currentTiming / $scope.durationTiming) * 100) + '%';
                                angular.element(progressElement).attr('style', width);
                                onDurationChangeDuringVideoPlay(this);
                            }
                        });

                        var progressElement = document.getElementById('progress' + videoElementsId);
                        progressElement.addEventListener('click', function (e) {
                            var videoElementInProcess = angular.element(element).find('video');
                            var videoElementsId = angular.element(videoElementInProcess).attr('id');
                            var progressElement = document.getElementById('progress' + videoElementsId);
                            var pos = (e.pageX - (this.offsetLeft + this.offsetParent.offsetLeft)) / this.offsetWidth;
                            var video = document.getElementById(videoElementsId);
                            video.currentTime = pos * video.duration;
                        });
                    }, 10);


                    //Full Screen Video
                    $scope.fullScreenVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        var videoContainer = videoElement.parentNode;
                        handleFullscreen(videoElement, videoContainer);

                    };
                    var isFullScreen = function () {
                        return !!(document.fullScreen || document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement);
                    };

                    // Fullscreen
                    var setFullscreenData = function (state, videoContainer) {
                        angular.element(videoContainer).attr('data-fullscreen', !!state);
                        angular.element(videoContainer).attr('data-state', !!state ? 'cancel-fullscreen' : 'go-fullscreen')

                    };
                    var handleFullscreen = function (video, videoContainer) {
                        if (isFullScreen()) {
                            if (document.exitFullscreen) document.exitFullscreen();
                            else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
                            else if (document.webkitCancelFullScreen) document.webkitCancelFullScreen();
                            else if (document.msExitFullscreen) document.msExitFullscreen();
                            setFullscreenData(false);
                        }
                        else {
                            if (videoContainer.requestFullscreen) videoContainer.requestFullscreen();
                            else if (videoContainer.mozRequestFullScreen) videoContainer.mozRequestFullScreen();
                            else if (videoContainer.webkitRequestFullScreen) {
                                video.webkitRequestFullScreen();
                            }
                            else if (videoContainer.msRequestFullscreen) videoContainer.msRequestFullscreen();
                            setFullscreenData(true);
                        }
                    };
                    document.addEventListener('fullscreenchange', function (e) {
                        setFullscreenData(!!(document.fullScreen || document.fullscreenElement));
                    });
                    document.addEventListener('webkitfullscreenchange', function () {
                        setFullscreenData(!!document.webkitIsFullScreen);
                    });
                    document.addEventListener('mozfullscreenchange', function () {
                        setFullscreenData(!!document.mozFullScreen);
                    });
                    document.addEventListener('msfullscreenchange', function () {
                        setFullscreenData(!!document.msFullscreenElement);
                    });

                    var tuneVolumeOfVideoPlayer = function (direction, video) {
                        if (direction) {
                            var currentVolume = Math.floor(video.volume * 10) / 10;
                            if (direction === '+') {
                                if (currentVolume < 1) video.volume += 0.1;
                            }
                            else if (direction === '-') {
                                if (currentVolume > 0) video.volume -= 0.1;
                            }
                            if (currentVolume <= 0) video.muted = true;
                            else video.muted = false;
                        }
                    };

                    // Modal
                    $scope.onViewAllComments = function (e) {
                        var videoNumber = parseInt(angular.element(e.target).attr('number')) - 1;
                        $scope.$emit("displayAllComments", {videoNumber: videoNumber});
                        $('#myModal').modal({
                            keyboard: false
                        })
                    };

                    //Comment
                    $scope.onCommentEnter = function (e) {
                        if (e.which && e.which === 13) {
                            $scope.userEnteredComment = $scope.inputComment;
                            $scope.inputComment = '';
                            $timeout(function () {
                                angular.element(document.getElementsByClassName('userEnteredComment')).addClass('animateComment');
                                $timeout(function () {
                                    $scope.userEnteredComment = '';
                                    angular.element(document.getElementsByClassName('userEnteredComment')).removeClass('animateComment');
                                }, 4000)
                            }, 4000)
                        }
                    };
                    //Like & Unlike
                    $scope.onLikeUnlike = function () {
                        var panelNumber = parseInt(angular.element(element).attr('number')) - 1;
                        var emojiContainer = angular.element(document.getElementsByClassName('emojiContainer'))[panelNumber];
                        angular.element(emojiContainer).addClass('show');
                        angular.element(emojiContainer).addClass('animateEmoji');
                        $timeout(function () {
                            angular.element(emojiContainer).removeClass('show');
                            angular.element(emojiContainer).removeClass('animateEmoji');
                        }, 4000)
                    }
                    //Previous & next Video
                    $scope.onPlayPreviousVideo = function () {
                        playVideoPreviousNNext("pre");
                    };
                    $scope.onPlayNextVideo = function () {
                        playVideoPreviousNNext("next");
                    };
                    function playVideoPreviousNNext(direction) {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var nextVideo = '';
                        if (direction === "pre") {
                            nextVideo = parseInt(videoElementsId) - 1;
                            if (nextVideo <= 5) {
                                nextVideo = 5;
                            }
                        } else {
                            nextVideo = parseInt(videoElementsId) + 1;
                            if (nextVideo >= 14) {
                                nextVideo = 14;
                            }
                        }
                        angular.element(videoElementInProcess).attr('id', nextVideo.toString());
                        angular.element(videoElementInProcess).find('source').attr('src', "resources/videos/" + nextVideo + ".mp4?" + Date.now());
                        angular.element(videoElementInProcess).find('source').attr('ng-src', "resources/videos/" + nextVideo + ".mp4?" + Date.now());
                        var video = document.getElementById(nextVideo.toString());
                        video.load();
                        video.play();
                    }
                }
            }
        })
        .filter("trustUrl", ['$sce', function ($sce) {
            return function (recordingUrl) {
                return $sce.trustAsResourceUrl(recordingUrl);
            };
        }]);
})();

