(function () {
    angular.module("dashboard")
    .controller("graphsDashboard", function ($scope, $location, dashboardFactory) {
        $scope.pageName = "Graph Dashboard Page";
         if (!sessionStorage.getItem('loginId')) {
             $location.path("/login");
         }
        $scope.logoutBtn = true;
        $scope.onLogout = function () {
            $location.path("/login");
            sessionStorage.removeItem('loginId');
        };
        $scope.onVideoDashboardBtnClick = function () {
            if (sessionStorage.getItem('loginId')) {
                $location.path("/video_dashboard")
                ;
            }
        };
        dashboardFactory.getGraphData().then(function (data) {

        }, function (data) {
            console.error(data)
        });
    });
})();