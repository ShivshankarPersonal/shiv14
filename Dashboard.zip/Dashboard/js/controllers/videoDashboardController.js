(function () {
    angular.module('dashboard')
        .controller("videoDashboard", function ($scope, $location, dashboardFactory, $timeout) {
            $scope.greeting = 'Video Dashboard';
            $scope.pageName = 'Video Dashboard Page';
             if (!sessionStorage.getItem("loginId")) {
                 $location.path("/login");
             }
            $scope.logoutBtn = true;
            $scope.onLogout = function () {
                $location.path('/login');
                sessionStorage.removeItem('loginId');
            };

            //Fetch Video Dashboard Data
            dashboardFactory.getVideoDetails().then(function (data, status, headers, config) {
                    $scope.gallaryVideos = data.gallaryVideos;
                    $scope.top4Videos = data.top4Videos;
                    $scope.firstVideoInGallary = data.gallaryVideos.splice(0, 1);
                    $timeout(function () {
                         $scope.playVideo($scope.firstVideoInGallary[0]);
                         $scope.muteVideo($scope.firstVideoInGallary[0]);
                         playAllTop4Videos();
                    }, 100)
                },
                function (data, status, headers, config) {
                    console.error(data)
                });
            function playAllTop4Videos() {
                var length = $scope.top4Videos.length;
                for (var i = 0; i < length; i++) {
                    $scope.playVideo($scope.top4Videos[i]);
                    $scope.muteVideo($scope.top4Videos[i]);
                }
            }

            $scope.onGraphBtnClick = function () {
                if (sessionStorage.getItem('loginId')) {
                    $location.path("/graphs_dashboard")
                    ;
                }
            };
            $scope.top4VideosContainer = true;
            $scope.videoGallaryContainer = false;
            $scope.onVideoGallary = function () {
                angular.element(document.getElementById("top4Videos")).addClass("passiveVideoNavigationBtn")
                angular.element(document.getElementById('videoGallary')).removeClass("passiveVideoNavigationBtn")
                $scope.top4VideosContainer = false;
                $scope.videoGallaryContainer = true;
                $scope.playVideo($scope.firstVideoInGallary[0]);

            };
            $scope.onTop4Videos = function () {
                //angular.element(document.getElementById('top4Videos’)).removeClass("passiveVideoNavigationBtn")
                angular.element(document.getElementById('top4Videos')).removeClass('passiveVideoNavigationBtn')
                angular.element(document.getElementById('videoGallary')).addClass('passiveVideoNavigationBtn');
                $scope.top4VideosContainer = true;
                $scope.videoGallaryContainer = false;
            };

            $scope.playVideo = function (videoDetails) {
                var videoURL = "resources/videos/" + videoDetails.videoURL + ".mp4?" + Date.now();
                var videoContainer = angular.element(document.getElementById('playGallaryVideo'));
                videoContainer.find('source[src]').attr('src', videoURL).attr('ng-src', videoURL);
                videoContainer.find('video').attr('id', videoDetails.videoURL);
                var video = document.getElementById(videoDetails.videoURL);
                if (video) {
                    video.load();
                    video.play();
                    video.currentTime = 0;
                }

            };

            $scope.muteVideo = function (videoDetails) {
                var videoContainer = angular.element(document.getElementById('playGallaryVideo'));
                var videoElementsId = videoContainer.find('video').attr('id');
                var videoElement = document.getElementById(videoContainer.find('video').attr('id'));
                //videoElement.muted = !videoElement.muted;
                videoElement.muted = true;
                var muteElement = angular.element(videoContainer).find('.' + 'mute' + videoElementsId);
                var isMuteIconPresent = angular.element(muteElement).hasClass('glyphicon-volume-off');
                if (isMuteIconPresent) {
                    angular.element(muteElement).removeClass('glyphicon-volume-off');
                    angular.element(muteElement).addClass('glyphicon-bullhorn');
                } else {
                    angular.element(muteElement).addClass('glyphicon-volume-off');
                    angular.element(muteElement).removeClass('glyphicon-bullhorn');
                }
            };

            //Modal
            $scope.$on("displayAllComments", function (e, data) {
                $scope.allComments = dashboardFactory.top4Videos[data.videoNumber].videoComments;
            })
        });
})();
